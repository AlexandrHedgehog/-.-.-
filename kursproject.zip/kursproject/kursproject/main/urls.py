from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('australia', views.about),
    path('bali', views.bali),
    path('kuba',views.kuba),
    path('seychelles', views.seychelles),
    path('portugalia', views.portugalia),
    path('marokko', views.marokko),
    path('tayvan', views.tayvan),
    path('formentera', views.formen),
    path('norway', views.norway),
    path('grecia', views.grecia),
    path('georgia', views.georgia),
]