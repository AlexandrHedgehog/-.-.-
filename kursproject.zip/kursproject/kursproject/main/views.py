from django.shortcuts import render
from django.http import HttpResponse


def index(request):
    return render(request, 'main/index.html')


def about(request):
    return render(request, 'main/australia.html')

def bali(request):
    return render(request, 'main/bali.html')

def kuba(request):
    return render(request, 'main/kuba.html')

def seychelles(request):
    return render(request, 'main/seychelles.html')

def portugalia(request):
    return render(request, 'main/portu.html')

def marokko(request):
    return render(request, 'main/marokko.html')

def tayvan(request):
    return render(request, 'main/tayvan.html')

def formen(request):
    return render(request, 'main/formen.html')

def norway(request):
    return render(request, 'main/norw.html')

def grecia(request):
    return render(request, 'main/grecia.html')

def georgia(request):
    return  render(request, 'main/geor.html')



